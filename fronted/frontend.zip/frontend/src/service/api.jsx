import axios from "axios";

const API = axios.create({
  baseURL: "https://tiny-url-2-degy.onrender.com", 
});

export default API;
